0000000000401b3b <start_farm>:
  401b3b:	b8 01 00 00 00       	mov    $0x1,%eax
  401b40:	c3                   	retq   

0000000000401b41 <setval_226>:
  401b41:	c7 07 58 c2 0f 7c    	movl   $0x7c0fc258,(%rdi)
  401b47:	c3                   	retq   

0000000000401b48 <addval_241>:
  401b48:	8d 87 48 89 c7 90    	lea    -0x6f3876b8(%rdi),%eax
  401b4e:	c3                   	retq   

0000000000401b4f <getval_387>:
  401b4f:	b8 48 89 c7 c3       	mov    $0xc3c78948,%eax
  401b54:	c3                   	retq   

0000000000401b55 <setval_413>:
  401b55:	c7 07 58 c3 f5 a3    	movl   $0xa3f5c358,(%rdi)
  401b5b:	c3                   	retq   

0000000000401b5c <getval_347>:
  401b5c:	b8 48 89 c7 c2       	mov    $0xc2c78948,%eax
  401b61:	c3                   	retq   

0000000000401b62 <addval_398>:
  401b62:	8d 87 e9 58 90 c7    	lea    -0x386fa717(%rdi),%eax
  401b68:	c3                   	retq   

0000000000401b69 <setval_168>:
  401b69:	c7 07 6f 2b 58 90    	movl   $0x90582b6f,(%rdi)
  401b6f:	c3                   	retq   

0000000000401b70 <getval_197>:
  401b70:	b8 48 89 c7 c7       	mov    $0xc7c78948,%eax
  401b75:	c3                   	retq   

0000000000401b76 <mid_farm>:
  401b76:	b8 01 00 00 00       	mov    $0x1,%eax
  401b7b:	c3                   	retq   

0000000000401b7c <add_xy>:
  401b7c:	48 8d 04 37          	lea    (%rdi,%rsi,1),%rax
  401b80:	c3                   	retq   

0000000000401b81 <setval_395>:
  401b81:	c7 07 48 99 e0 90    	movl   $0x90e09948,(%rdi)
  401b87:	c3                   	retq   

0000000000401b88 <getval_137>:
  401b88:	b8 48 89 e0 c2       	mov    $0xc2e08948,%eax
  401b8d:	c3                   	retq   

0000000000401b8e <setval_491>:
  401b8e:	c7 07 48 89 e0 c7    	movl   $0xc7e08948,(%rdi)
  401b94:	c3                   	retq   

0000000000401b95 <getval_254>:
  401b95:	b8 89 ca 08 db       	mov    $0xdb08ca89,%eax
  401b9a:	c3                   	retq   

0000000000401b9b <getval_235>:
  401b9b:	b8 a9 ca 08 c0       	mov    $0xc008caa9,%eax
  401ba0:	c3                   	retq   

0000000000401ba1 <setval_167>:
  401ba1:	c7 07 89 ca 60 c0    	movl   $0xc060ca89,(%rdi)
  401ba7:	c3                   	retq   

0000000000401ba8 <addval_276>:
  401ba8:	8d 87 8b ca 20 c0    	lea    -0x3fdf3575(%rdi),%eax
  401bae:	c3                   	retq   

0000000000401baf <addval_118>:
  401baf:	8d 87 89 d6 c7 20    	lea    0x20c7d689(%rdi),%eax
  401bb5:	c3                   	retq   

0000000000401bb6 <addval_297>:
  401bb6:	8d 87 e7 89 c1 91    	lea    -0x6e3e7619(%rdi),%eax
  401bbc:	c3                   	retq   

0000000000401bbd <addval_468>:
  401bbd:	8d 87 89 d6 18 d2    	lea    -0x2de72977(%rdi),%eax
  401bc3:	c3                   	retq   

0000000000401bc4 <setval_317>:
  401bc4:	c7 07 8d ca 90 c3    	movl   $0xc390ca8d,(%rdi)
  401bca:	c3                   	retq   

0000000000401bcb <getval_425>:
  401bcb:	b8 52 68 89 e0       	mov    $0xe0896852,%eax
  401bd0:	c3                   	retq   

0000000000401bd1 <setval_285>:
  401bd1:	c7 07 8b 89 d6 c1    	movl   $0xc1d6898b,(%rdi)
  401bd7:	c3                   	retq   

0000000000401bd8 <setval_388>:
  401bd8:	c7 07 3b 40 89 e0    	movl   $0xe089403b,(%rdi)
  401bde:	c3                   	retq   

0000000000401bdf <getval_203>:
  401bdf:	b8 48 89 e0 90       	mov    $0x90e08948,%eax
  401be4:	c3                   	retq   

0000000000401be5 <addval_446>:
  401be5:	8d 87 8b c1 08 c9    	lea    -0x36f73e75(%rdi),%eax
  401beb:	c3                   	retq   

0000000000401bec <getval_160>:
  401bec:	b8 89 d6 08 d2       	mov    $0xd208d689,%eax
  401bf1:	c3                   	retq   

0000000000401bf2 <setval_134>:
  401bf2:	c7 07 89 d6 92 c3    	movl   $0xc392d689,(%rdi)
  401bf8:	c3                   	retq   

0000000000401bf9 <getval_401>:
  401bf9:	b8 89 c1 18 db       	mov    $0xdb18c189,%eax
  401bfe:	c3                   	retq   

0000000000401bff <addval_483>:
  401bff:	8d 87 89 c1 18 d2    	lea    -0x2de73e77(%rdi),%eax
  401c05:	c3                   	retq   

0000000000401c06 <addval_477>:
  401c06:	8d 87 a9 ca 38 c0    	lea    -0x3fc73557(%rdi),%eax
  401c0c:	c3                   	retq   

0000000000401c0d <getval_138>:
  401c0d:	b8 48 89 e0 94       	mov    $0x94e08948,%eax
  401c12:	c3                   	retq   

0000000000401c13 <addval_108>:
  401c13:	8d 87 89 c1 90 90    	lea    -0x6f6f3e77(%rdi),%eax
  401c19:	c3                   	retq   

0000000000401c1a <getval_352>:
  401c1a:	b8 89 ca 08 c0       	mov    $0xc008ca89,%eax
  401c1f:	c3                   	retq   

0000000000401c20 <setval_181>:
  401c20:	c7 07 89 d6 94 c0    	movl   $0xc094d689,(%rdi)
  401c26:	c3                   	retq   

0000000000401c27 <addval_458>:
  401c27:	8d 87 8d c1 90 c3    	lea    -0x3c6f3e73(%rdi),%eax
  401c2d:	c3                   	retq   

0000000000401c2e <setval_481>:
  401c2e:	c7 07 48 89 e0 c3    	movl   $0xc3e08948,(%rdi)
  401c34:	c3                   	retq   

0000000000401c35 <getval_270>:
  401c35:	b8 1c 89 d6 90       	mov    $0x90d6891c,%eax
  401c3a:	c3                   	retq   

0000000000401c3b <setval_152>:
  401c3b:	c7 07 88 d6 90 90    	movl   $0x9090d688,(%rdi)
  401c41:	c3                   	retq   

0000000000401c42 <getval_402>:
  401c42:	b8 7a 89 ca c2       	mov    $0xc2ca897a,%eax
  401c47:	c3                   	retq   

0000000000401c48 <addval_383>:
  401c48:	8d 87 89 c1 38 c9    	lea    -0x36c73e77(%rdi),%eax
  401c4e:	c3                   	retq   

0000000000401c4f <setval_457>:
  401c4f:	c7 07 8b c1 84 c9    	movl   $0xc984c18b,(%rdi)
  401c55:	c3                   	retq   

0000000000401c56 <end_farm>:
  401c56:	b8 01 00 00 00       	mov    $0x1,%eax
  401c5b:	c3                   	retq   

